﻿var connectionStatusesEnum = {
    Connecting: 0,
    Connected: 1,
    Reconnecting: 2,
    Disconnected: 4
};